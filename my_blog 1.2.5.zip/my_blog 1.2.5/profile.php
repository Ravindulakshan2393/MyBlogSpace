<?php
require_once "includes/config.php";
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$message = "";

// === Handle profile picture upload ===
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["profile_pic"])) {
    $file = $_FILES["profile_pic"];
    $targetDir = "uploads/profile_pics/";
    $fileName = time() . "_" . basename($file["name"]);
    $targetFile = $targetDir . $fileName;

    // Create folder if missing
    if (!file_exists($targetDir)) mkdir($targetDir, 0777, true);

    $allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/webp"];
    if (!in_array($file["type"], $allowedTypes)) {
        $message = "❌ Only JPG, PNG, or WEBP images allowed.";
    } else {
        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
            $stmt = $conn->prepare("UPDATE user SET profile_pic=? WHERE id=?");
            $stmt->bind_param("si", $targetFile, $user_id);
            $stmt->execute();
            $_SESSION["profile_pic"] = $targetFile;
            $message = "✅ Profile picture updated!";
        } else {
            $message = "❌ Upload failed.";
        }
    }
}

// === Fetch user info ===
$stmt = $conn->prepare("SELECT username, email, profile_pic, created_at FROM user WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

include "includes/header.php";
?>

<h2>👤 My Profile</h2>

<div class="form-box" style="max-width:500px; margin:auto; text-align:center;">

  <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

  <!-- Profile Picture -->
  <div style="text-align:center; margin-bottom:10px;">
    <img 
      src="<?php echo htmlspecialchars($user['profile_pic'] ?? 'assets/images/default-avatar.png'); ?>" 
      alt="Profile Picture" 
      class="profile-pic"
      style="width:120px; height:120px; border-radius:50%; object-fit:cover; border:2px solid var(--border);">
  </div>

  <form method="POST" enctype="multipart/form-data">
    <input type="file" name="profile_pic" accept="image/*" required>
    <button type="submit">Upload</button>
  </form>

  <hr style="margin:20px 0;">

  <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
  <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
  <p><strong>Account Created:</strong> <?php echo htmlspecialchars($user['created_at']); ?></p>

  <div style="margin-top:20px;">
    <a href="change_password.php" class="button">🔑 Change Password</a>
    <a href="profile_edit.php" class="button">✏️ Edit Profile</a>
    <a href="index.php" class="button">🏠 Home</a>
    <a href="logout.php" class="button">🚪 Logout</a>
  </div>

</div>

<?php include "includes/footer.php"; ?>
