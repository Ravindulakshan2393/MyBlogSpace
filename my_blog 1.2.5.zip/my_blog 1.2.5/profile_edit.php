<?php
require_once "includes/config.php";
if (!isset($_SESSION['user_id'])) header("Location: login.php");

$user_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    // handle file
    if (!empty($_FILES['profile_pic']['name'])) {
        $targetDir = __DIR__ . '/uploads/profile_pics/';
        if (!is_dir($targetDir)) mkdir($targetDir, 0755, true);
        $filename = time() . '_' . basename($_FILES['profile_pic']['name']);
        $targetFile = $targetDir . $filename;
        $ext = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];
        if (!in_array($ext, $allowed)) $message = "Invalid image type.";
        else {
            move_uploaded_file($_FILES['profile_pic']['tmp_name'], $targetFile);
            $profile_path = 'uploads/profile_pics/' . $filename;
        }
    }
    if (!$message) {
        if (isset($profile_path)) {
            $upd = $conn->prepare("UPDATE user SET username = ?, profile_pic = ? WHERE id = ?");
            $upd->bind_param("ssi", $username, $profile_path, $user_id);
        } else {
            $upd = $conn->prepare("UPDATE user SET username = ? WHERE id = ?");
            $upd->bind_param("si", $username, $user_id);
        }
        if ($upd->execute()) $message = "Profile updated.";
        else $message = "Update error: " . $conn->error;
    }
}

// fetch current values
$stmt = $conn->prepare("SELECT username, email, profile_pic FROM user WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>
<?php include "includes/header.php"; ?>

<h2>Edit Profile</h2>
<?php if ($message) echo "<p>$message</p>"; ?>
<form method="post" enctype="multipart/form-data">
  <label>Username</label><br>
  <input name="username" value="<?php echo htmlspecialchars($user['username']); ?>"><br><br>

  <label>Profile Picture</label><br>
  <?php if (!empty($user['profile_pic'])): ?>
    <img src="<?php echo htmlspecialchars($user['profile_pic']); ?>" style="width:100px; border-radius:8px;"><br>
  <?php endif; ?>
  <input type="file" name="profile_pic"><br><br>

  <button type="submit">Save</button>
</form>

<?php include "includes/footer.php"; ?>
