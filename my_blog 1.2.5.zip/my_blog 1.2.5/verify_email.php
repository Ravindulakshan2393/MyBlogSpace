<?php
require_once "includes/config.php";

if (!isset($_GET['token'])) {
    echo "❌ Invalid verification link.";
    exit();
}

$token = $_GET['token'];

$stmt = $conn->prepare("SELECT id FROM user WHERE verify_token = ? AND is_verified = 0");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    $update = $conn->prepare("UPDATE user SET is_verified = 1, verify_token = NULL WHERE id = ?");
    $update->bind_param("i", $user['id']);
    if ($update->execute()) {
        echo "✅ Email verified! You can now <a href='login.php'>login</a>.";
    } else {
        echo "❌ Verification failed.";
    }
} else {
    echo "❌ Invalid or expired token.";
}
?>
