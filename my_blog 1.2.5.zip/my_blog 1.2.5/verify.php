<?php
require_once "includes/config.php";

if (!isset($_GET['token'])) {
    die("❌ Invalid verification link.");
}

$token = $_GET['token'];

// Find user with this token
$stmt = $conn->prepare("SELECT * FROM user WHERE verify_token = ?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if ($user['is_verified'] == 1) {
        echo "✅ Your account is already verified.";
    } else {
        // Mark as verified
        $update = $conn->prepare("UPDATE user SET is_verified = 1, verify_token = NULL WHERE id = ?");
        $update->bind_param("i", $user['id']);
        $update->execute();

        echo "🎉 Your email has been verified! You can now <a href='login.php'>login</a>.";
    }
} else {
    echo "❌ Invalid or expired token.";
}
?>
