<?php
// =======================================
// ⚙️ CONFIGURATION FILE (includes/config.php)
// =======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 🔐 Load environment variables from .env
function loadEnv($path)
{
    if (!file_exists($path)) return;
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#') continue;
        [$name, $value] = array_map('trim', explode('=', $line, 2));
        $value = trim($value, "\"'");
        if (!isset($_ENV[$name])) {
            $_ENV[$name] = $value;
            putenv("$name=$value");
        }
    }
}

// Load .env from project root
loadEnv(__DIR__ . '/../.env');

// 🧭 Database credentials (with fallback defaults)
$host = $_ENV['DB_HOST'] ?? 'localhost';
$user = $_ENV['DB_USER'] ?? 'root';
$pass = $_ENV['DB_PASS'] ?? '';
$name = $_ENV['DB_NAME'] ?? 'blog_app';

// 🗄️ Create MySQL connection
$conn = new mysqli($host, $user, $pass, $name);

// ❌ Stop if DB connection fails
if ($conn->connect_error) {
    die("❌ Database connection failed: " . $conn->connect_error);
}
?>
