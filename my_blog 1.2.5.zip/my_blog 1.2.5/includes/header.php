<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

// Detect base path for pages inside or outside /blog/
$basePath = (strpos($_SERVER['PHP_SELF'], '/blog/') !== false) ? '../' : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="<?php echo $basePath; ?>assets/css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <script>
    // --- THEME HANDLING ---
    function setLogo() {
      const logo = document.getElementById('siteLogo');
      const isDark = document.body.classList.contains('dark');
      if (logo) {
        logo.src = isDark 
          ? '<?php echo $basePath; ?>assets/images/logo-dark.png'
          : '<?php echo $basePath; ?>assets/images/logo-light.png';
      }
    }

    function toggleTheme() {
      document.body.classList.toggle('dark');
      localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
      setLogo();
    }

    document.addEventListener("DOMContentLoaded", () => {
      if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark');
      }
      setLogo();
    });

    // --- MOBILE MENU TOGGLE ---
    function toggleMenu() {
      const nav = document.getElementById("navLinks");
      if (nav) nav.classList.toggle("open");
    }

    // Auto-close when clicking a nav link (mobile)
    document.addEventListener("click", (e) => {
      const nav = document.getElementById("navLinks");
      if (!nav) return;

      if (e.target.closest('.nav-links a') && nav.classList.contains('open')) {
        nav.classList.remove('open');
      }
    });

    // Auto-close menu when resizing to desktop
    window.addEventListener('resize', () => {
      const nav = document.getElementById("navLinks");
      if (window.innerWidth > 900 && nav && nav.classList.contains('open')) {
        nav.classList.remove('open');
      }
    });
  </script>
</head>

<body>
  <header class="navbar">
    <div class="logo-section">
      <button class="theme-toggle" onclick="toggleTheme()">🌞 / 🌙</button>

      <!-- Clickable Logo -->
      <a href="<?php echo $basePath; ?>index.php" class="logo-link">
        <img id="siteLogo"
             src="<?php echo $basePath; ?>assets/images/logo-light.png"
             alt="MyBlogSpace Logo"
             class="logo">
      </a>
 
      <!-- <div class="blog-title">
        <h1>MyBlogSpace</h1>
        <p>Share your ideas, inspire others ✨</p>
      </div> -->
    </div>

    <!-- 🍔 Hamburger Menu -->
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>

    <!-- Navigation Links -->
    <nav class="nav-links" id="navLinks">
      <a href="<?php echo $basePath; ?>index.php">🏠 Home</a>
      <a href="<?php echo $basePath; ?>blog/create.php">➕ New Blog</a>
      <a href="<?php echo $basePath; ?>my_posts.php">📃 My Posts</a>
      <a href="<?php echo $basePath; ?>profile.php">👤 Profile</a>
      <a href="<?php echo $basePath; ?>logout.php">➡️ Logout</a>
    </nav>
  </header>

  <hr>
 </br>