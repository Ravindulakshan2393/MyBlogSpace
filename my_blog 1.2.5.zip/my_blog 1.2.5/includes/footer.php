<footer style="text-align:center; margin-top:40px; color:var(--text); font-size:14px;">
  <hr>
  <br>
  <div class="blog-title">
        <h1>MyBlogSpace</h1>
        <p>Share your ideas, inspire others ✨</p>
      </div>
  © <?php echo date("Y"); ?> MyBlogSpace — Created by pererawslr
</footer>
