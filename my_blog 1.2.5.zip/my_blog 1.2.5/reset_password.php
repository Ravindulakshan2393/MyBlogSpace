<?php
require_once "includes/config.php";
session_start();

$message = "";

if (isset($_GET["token"])) {
    $token = $_GET["token"];

    $stmt = $conn->prepare("SELECT id, reset_expires FROM user WHERE reset_token=?");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        $expires = strtotime($user["reset_expires"]);

        if ($expires < time()) {
            $message = "⏰ This link has expired.";
        } elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
            $password = $_POST["password"];
            $confirm = $_POST["confirm"];

            if ($password !== $confirm) {
                $message = "⚠️ Passwords do not match.";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $update = $conn->prepare("UPDATE user SET password=?, reset_token=NULL, reset_expires=NULL WHERE id=?");
                $update->bind_param("si", $hashed, $user["id"]);
                $update->execute();

                $message = "✅ Password updated successfully. <a href='login.php'>Login now</a>";
            }
        }
    } else {
        $message = "❌ Invalid or expired link.";
    }
} else {
    $message = "❌ No token provided.";
}

include "includes/header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<h2>🔐 Reset Password</h2>

<div class="form-box">
  <?php if ($message) echo "<p>$message</p>"; ?>

  <?php if (isset($user) && strtotime($user["reset_expires"]) > time()) { ?>
  <form method="POST">
    <label>New Password:</label>
    <input type="password" name="password" required>
    <label>Confirm Password:</label>
    <input type="password" name="confirm" required>
    <button type="submit">Update Password</button>
  </form>
  <?php } ?>
</div>

<?php include "includes/footer.php"; ?>
</body>
</html>
