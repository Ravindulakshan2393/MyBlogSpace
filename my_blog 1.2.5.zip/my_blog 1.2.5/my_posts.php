<?php
session_start();
require_once "includes/config.php";

// Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

// Fetch only this user's blogs
$stmt = $conn->prepare("SELECT * FROM blogpost WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Posts - My Blog</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<?php include "includes/header.php"; ?>

<div style="max-width: 800px; margin: 0 auto; padding: 0 20px;">
  <h2>👤 My Posts (<?php echo htmlspecialchars($_SESSION["username"]); ?>)</h2>
  
  <?php
  
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {

        echo "<div class='blog' style='display:flex; align-items:flex-start; gap:15px;'>";

        // Left side - text
        echo "<div style='flex:1;'>";
        echo "<h4><a href='blog/view.php?id=" . $row['id'] . "'>" . htmlspecialchars($row['title']) . "</a></h4>";
        echo "<p class='meta'>Posted on " . $row['created_at'] . "</p>";
        echo "<p>" . nl2br(substr(htmlspecialchars($row['content']), 0, 120)) . "...</p>";
        echo "<p>
                <a href='blog/edit.php?id=" . $row['id'] . "'>✏️ Edit</a> | 
                <a href='blog/delete.php?id=" . $row['id'] . "' style='color:red;'>🗑️ Delete</a>
              </p>";
        echo "</div>";

        // Right side - image (if exists)
        if (!empty($row['image'])) {
            echo "<div style='flex-shrink:0;'>";
            echo "<img src='uploads/" . htmlspecialchars($row['image']) . "' alt='Blog Image' style='width:120px; height:100px; object-fit:cover; border-radius:8px;'>";
            echo "</div>";
        }

        echo "</div>";
    }
} else {
    echo "<p>You haven't posted anything yet. <a href='blog/create.php'>Write your first blog!</a></p>";
}

  ?>
</div>

<?php include "includes/footer.php"; ?>
</body>
</html>