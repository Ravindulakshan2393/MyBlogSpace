<?php
session_start();
require_once "includes/config.php";

// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

// Handle search
$search = "";
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $query = "
        SELECT blogpost.*, user.username 
        FROM blogpost 
        JOIN user ON blogpost.user_id = user.id 
        WHERE blogpost.title LIKE ? OR blogpost.content LIKE ?
        ORDER BY blogpost.created_at DESC
    ";
    $stmt = $conn->prepare($query);
    $like = "%$search%";
    $stmt->bind_param("ss", $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    // Default: show all blogs
    $query = "
        SELECT blogpost.*, user.username 
        FROM blogpost 
        JOIN user ON blogpost.user_id = user.id 
        ORDER BY blogpost.created_at DESC
    ";
    $result = $conn->query($query);
}

include "includes/header.php";
?>

<h2>👋 Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h2>

<h3>📰 Recent Blogs</h3>
<form method="GET" action="" style="margin-bottom: 20px;">
    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" 
           placeholder="🔍 Search blogs..." 
           style="width: 70%; padding: 6px;">
    <button type="submit" style="padding: 6px 12px;">Search</button>
</form>

<?php
if (!empty($search)) {
    echo "<p>🔍 Showing results for: <strong>" . htmlspecialchars($search) . "</strong></p>";
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='blog' style='display:flex; align-items:flex-start; gap:15px;'>";
        
        // Left side - text
        echo "<div style='flex:1;'>";
        echo "<h4><a href='blog/view.php?id=" . $row['id'] . "'>" . htmlspecialchars($row['title']) . "</a></h4>";
        echo "<p class='meta'>By " . htmlspecialchars($row['username']) . " | " . $row['created_at'] . "</p>";
        echo "<p>" . nl2br(substr(htmlspecialchars($row['content']), 0, 120)) . "...</p>";
        
        if ($row['user_id'] == $_SESSION['user_id']) {
            echo "<p>
                <a href='blog/edit.php?id=" . $row['id'] . "'>✏️ Edit</a> | 
                <a href='blog/delete.php?id=" . $row['id'] . "' style='color:red;'>🗑️ Delete</a>
            </p>";
        }
        echo "</div>";
        
        // Right side - image (if available)
        if (!empty($row['image'])) {
            echo "<div style='flex-shrink:0;'>";
            echo "<img src='uploads/" . htmlspecialchars($row['image']) . "' alt='Blog Image' style='width:120px; height:100px; object-fit:cover; border-radius:8px;'>";
            echo "</div>";
        }
        
        echo "</div>";
    }
} else {
    echo "<p>No blogs yet. <a href='blog/create.php'>Write your first one!</a></p>";
}

include "includes/footer.php";
?>