<?php
// ===============================
// 🚪 LOGOUT SCRIPT
// ===============================
session_start();

// Remove Remember Me cookie
if (isset($_COOKIE["remember_token"])) {
    setcookie("remember_token", "", time() - 3600, "/");
}

// Clear session
session_unset();
session_destroy();

// Redirect to login
header("Location: login.php");
exit();
?>
