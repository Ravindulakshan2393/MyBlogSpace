<?php
require_once "includes/config.php";
if (!isset($_SESSION['user_id'])) header("Location: login.php");
$user_id = $_SESSION['user_id'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // fetch current hash
    $stmt = $conn->prepare("SELECT password FROM user WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    if (!password_verify($current, $row['password'])) $message = "Current password incorrect.";
    elseif (strlen($new) < 6) $message = "New password too short.";
    elseif ($new !== $confirm) $message = "Passwords don't match.";
    else {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $upd = $conn->prepare("UPDATE user SET password = ? WHERE id = ?");
        $upd->bind_param("si", $hash, $user_id);
        $upd->execute();
        $message = "Password changed.";
    }
}
include "includes/header.php";
?>
<h2>Change Password</h2>
<?php if ($message) echo "<p>$message</p>"; ?>
<form method="post">
  <label>Current Password</label><br>
  <input type="password" name="current_password"><br><br>
  <label>New Password</label><br>
  <input type="password" name="new_password"><br><br>
  <label>Confirm New Password</label><br>
  <input type="password" name="confirm_password"><br><br>
  <button type="submit">Change Password</button>
</form>
<?php include "includes/footer.php"; ?>
