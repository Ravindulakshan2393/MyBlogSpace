<?php
require_once "includes/config.php";
session_start();

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"]);
    if (empty($email)) {
        $message = "⚠️ Please enter your email.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM user WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $token = bin2hex(random_bytes(32));
            $expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

            $update = $conn->prepare("UPDATE user SET reset_token=?, reset_expires=? WHERE id=?");
            $update->bind_param("ssi", $token, $expires, $user["id"]);
            $update->execute();

            // ✉️ Send email (use your real mail system)
            $resetLink = "http://localhost/my_blog/reset_password.php?token=$token";
            $message = "✅ Password reset link generated! (Normally emailed)<br>
                        <a href='$resetLink'>$resetLink</a>";
        } else {
            $message = "❌ No account found with that email.";
        }
    }
}

include "includes/header.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Forgot Password</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<h2>🔑 Forgot Password</h2>

<div class="form-box">
  <?php if ($message) echo "<p>$message</p>"; ?>

  <form method="POST">
    <label>Email:</label>
    <input type="email" name="email" required>
    <button type="submit">Send Reset Link</button>
  </form>

  <p><a href="login.php">⬅️ Back to Login</a></p>
</div>

<?php include "includes/footer.php"; ?>
</body>
</html>