<?php
session_start();
require_once "../includes/config.php";

// Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Check if blog ID exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit();
}

$blog_id = intval($_GET['id']);
$user_id = $_SESSION["user_id"];
$message = "";

// Verify the blog belongs to the logged-in user
$stmt = $conn->prepare("SELECT * FROM blogpost WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $blog_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "❌ Blog not found or you don't have permission to delete it.";
    exit();
}

// Handle confirmation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm'])) {
    if ($_POST['confirm'] === 'yes') {
        // First, get image name to delete file
        $blog = $result->fetch_assoc();
        $imageName = $blog['image'];
        
        $delete = $conn->prepare("DELETE FROM blogpost WHERE id = ? AND user_id = ?");
        $delete->bind_param("ii", $blog_id, $user_id);
        
        if ($delete->execute()) {
            // Delete image file if exists
            if (!empty($imageName) && file_exists("../uploads/" . $imageName)) {
                unlink("../uploads/" . $imageName);
            }
            $message = "✅ Blog deleted successfully!";
            header("Refresh: 2; url=../index.php");
        } else {
            $message = "❌ Error deleting blog.";
        }
    } else {
        header("Location: ../index.php");
        exit();
    }
}

include "../includes/header.php";
?>

<div class="confirm-box">
    <h2>🗑️ Delete Blog</h2>
    <?php if (!empty($message)) echo "<p>$message</p>"; ?>
    
    <?php if (empty($message)): ?>
        <p>Are you sure you want to delete this blog post?</p>
        <form method="POST" action="">
            <button type="submit" name="confirm" value="yes" class="button" style="background:red;">Yes, Delete</button>
            <a href="../index.php" class="button">Cancel</a>
        </form>
    <?php endif; ?>
</div>

<?php include "../includes/footer.php"; ?>
</body>
</html>