<?php
session_start();
require_once "../includes/config.php";

// Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);
    $imageName = null;

    // If user selected a file
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "../uploads/";
        
        // Create uploads directory if it doesn't exist
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        
        $imageName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Allow only safe image types
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];
        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                // ✅ File uploaded successfully
            } else {
                $message = "⚠️ Error uploading image file.";
            }
        } else {
            $message = "⚠️ Invalid file type. Only JPG, JPEG, PNG, or GIF allowed.";
        }
    }

    if (empty($title) || empty($content)) {
        $message = "⚠️ Please fill in all fields.";
    } else if (empty($message)) { // Only proceed if no upload error
        // Fixed SQL - removed extra parameters
        $stmt = $conn->prepare("INSERT INTO blogpost (user_id, title, content, image) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $_SESSION["user_id"], $title, $content, $imageName);

        if ($stmt->execute()) {
            $message = "✅ Blog added successfully!";
            // Clear form
            $title = $content = "";
        } else {
            $message = "❌ Error adding blog: " . $conn->error;
        }
    }
}

include "../includes/header.php";
?>

<h2>📝 Create New Blog</h2>
<?php if (!empty($message)) echo "<p>$message</p>"; ?>

<form method="POST" action="" enctype="multipart/form-data">
    <label>Title:</label><br>
    <input type="text" name="title" value="<?php echo isset($title) ? htmlspecialchars($title) : ''; ?>" style="width:300px;"><br><br>

    <label>Content:</label><br>
    <textarea name="content" rows="6" cols="40"><?php echo isset($content) ? htmlspecialchars($content) : ''; ?></textarea><br><br>
    
    <label>Upload Image (Optional):</label><br>
    <input type="file" name="image"><br><br>

    <button type="submit">Add Blog</button>
</form>

<p><a href="../index.php">🏠 Back to Home</a></p>

<?php include "../includes/footer.php"; ?>
</body>
</html>