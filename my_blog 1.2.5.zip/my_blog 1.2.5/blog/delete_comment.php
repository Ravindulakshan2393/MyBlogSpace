<?php
session_start();
require_once "../includes/config.php";

// 🛡 Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// ✅ Validate comment ID - FIXED PARAMETER NAME
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "❌ No comment ID provided.";
    exit();
}

$comment_id = intval($_GET['id']);
$user_id = $_SESSION["user_id"];

// 🔍 Check ownership
$stmt = $conn->prepare("SELECT * FROM comments WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $comment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "❌ Comment not found or no permission to delete it.";
    exit();
}

$comment = $result->fetch_assoc();
$blog_id = $comment['blog_id'];

// 🗑 Delete it
$delete = $conn->prepare("DELETE FROM comments WHERE id = ? AND user_id = ?");
$delete->bind_param("ii", $comment_id, $user_id);

if ($delete->execute()) {
    echo "success";
} else {
    echo "❌ Error deleting comment.";
}
?>