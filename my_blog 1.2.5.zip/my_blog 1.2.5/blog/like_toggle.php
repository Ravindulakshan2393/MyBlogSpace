<?php
session_start();
require_once "../includes/config.php";

if (!isset($_SESSION["user_id"])) {
    echo "error:not_logged_in";
    exit();
}

$user_id = $_SESSION["user_id"];
$type = $_POST["type"] ?? "";  // 'post' or 'comment'
$id = intval($_POST["id"] ?? 0);

if (!$type || !$id) {
    echo "error:missing_fields";
    exit();
}

if ($type === "post") {
    $table = "post_likes";
    $column = "blog_id";
} elseif ($type === "comment") {
    $table = "comment_likes";
    $column = "comment_id";
} else {
    echo "error:invalid_type";
    exit();
}

// Check if user already liked
$check = $conn->prepare("SELECT * FROM $table WHERE $column = ? AND user_id = ?");
$check->bind_param("ii", $id, $user_id);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    // Unlike (remove like)
    $stmt = $conn->prepare("DELETE FROM $table WHERE $column = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    echo "unliked";
} else {
    // Like
    $stmt = $conn->prepare("INSERT INTO $table ($column, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    echo "liked";
}
?>
