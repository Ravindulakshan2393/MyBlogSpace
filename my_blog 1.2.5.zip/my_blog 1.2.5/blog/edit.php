<?php
session_start();
require_once "../includes/config.php";

// Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

// Check if blog ID exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../index.php");
    exit();
}

$blog_id = intval($_GET['id']);
$user_id = $_SESSION["user_id"];
$message = "";

// Fetch the blog and ensure it belongs to the logged-in user
$stmt = $conn->prepare("SELECT * FROM blogpost WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $blog_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "❌ Blog not found or you don’t have permission to edit it.";
    exit();
}

$blog = $result->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST["title"]);
    $content = trim($_POST["content"]);
    $oldImage = $blog['image'];
    $newImage = $oldImage;

    // Handle image upload (optional)
    if (!empty($_FILES["image"]["name"])) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        $imageName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowedTypes = ["jpg", "jpeg", "png", "gif"];

        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                // Delete old image if exists
                if (!empty($oldImage) && file_exists("../uploads/" . $oldImage)) {
                    unlink("../uploads/" . $oldImage);
                }
                $newImage = $imageName;
            } else {
                $message = "⚠️ Error uploading image.";
            }
        } else {
            $message = "⚠️ Invalid file type (only JPG, JPEG, PNG, GIF).";
        }
    }

    if (empty($title) || empty($content)) {
        $message = "⚠️ Please fill in all fields.";
    } elseif (empty($message)) {
        $update = $conn->prepare("UPDATE blogpost SET title=?, content=?, image=?, updated_at=NOW() WHERE id=? AND user_id=?");
        $update->bind_param("sssii", $title, $content, $newImage, $blog_id, $user_id);
        if ($update->execute()) {
            $message = "✅ Blog updated successfully!";
            $blog['title'] = $title;
            $blog['content'] = $content;
            $blog['image'] = $newImage;
        } else {
            $message = "❌ Error updating blog.";
        }
    }
}

// Include header
include "../includes/header.php";
?>

<div class="form-box">
  <h2>✏️ Edit Blog</h2>
  <?php if (!empty($message)) echo "<p>$message</p>"; ?>

  <form method="POST" action="" enctype="multipart/form-data">
    <label>Title:</label><br>
    <input type="text" name="title" value="<?php echo htmlspecialchars($blog['title']); ?>"><br><br>

    <label>Content:</label><br>
    <textarea name="content" rows="6"><?php echo htmlspecialchars($blog['content']); ?></textarea><br><br>

    <label>Current Image:</label><br>
    <?php if (!empty($blog['image'])): ?>
        <img src="../uploads/<?php echo htmlspecialchars($blog['image']); ?>" alt="Blog Image" style="max-width:100%; border-radius:8px; margin:10px 0;"><br>
    <?php else: ?>
        <p>No image uploaded.</p>
    <?php endif; ?>

    <label>Change Image (Optional):</label><br>
    <input type="file" name="image"><br><br>

    <button type="submit">Update Blog</button>
  </form>

  <p><a href="../index.php" class="button">← Back to Home</a></p>
</div>

<?php include "../includes/footer.php"; ?>
</body>
</html>
