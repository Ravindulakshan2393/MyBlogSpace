<?php
session_start();
require_once "../includes/config.php";

if (!isset($_GET['blog_id'])) {
    exit();
}

$blog_id = intval($_GET['blog_id']);

// Fetch all comments for this blog (including parent-child relationships)
$stmt = $conn->prepare("
    SELECT comments.*, user.username 
    FROM comments 
    JOIN user ON comments.user_id = user.id 
    WHERE comments.blog_id = ?
    ORDER BY 
        CASE WHEN comments.parent_id IS NULL THEN comments.id ELSE comments.parent_id END,
        comments.created_at ASC
");
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$result = $stmt->get_result();

// Helper for time ago
function timeAgo($datetime) {
    $timestamp = strtotime($datetime);
    $diff = time() - $timestamp;

    if ($diff < 60)
        return "just now";
    elseif ($diff < 3600)
        return floor($diff / 60) . " minutes ago";
    elseif ($diff < 86400)
        return floor($diff / 3600) . " hours ago";
    elseif ($diff < 172800)
        return "yesterday";
    else
        return floor($diff / 86400) . " days ago";
}

// Function to display comments recursively
function displayComment($comment, $level = 0, $conn) {
    $indent = $level * 30; // 30px indent per level
    
    echo "<div class='comment-item' id='comment-{$comment['id']}' style='margin-left: {$indent}px; border-left: " . ($level > 0 ? "2px solid var(--primary)" : "none") . "'>";
    
    // 🧑 Username + time
    echo "<div class='comment-header'>";
    echo "<span class='comment-author'>" . htmlspecialchars($comment['username']) . "</span>";
    echo "<span class='comment-time'>🕒 " . timeAgo($comment['created_at']);
    if (isset($comment['updated_at']) && $comment['updated_at'] !== $comment['created_at']) {
        echo " (edited)";
    }
    echo "</span>";
    echo "</div>";

    // 🗨️ Comment text
    echo "<div class='comment-text'>" . nl2br(htmlspecialchars($comment['comment'])) . "</div>";

    // ❤️ LIKE FEATURE FOR COMMENTS
    // Get like count
    $like_stmt = $conn->prepare("SELECT COUNT(*) AS total FROM comment_likes WHERE comment_id = ?");
    $like_stmt->bind_param("i", $comment['id']);
    $like_stmt->execute();
    $like_result = $like_stmt->get_result()->fetch_assoc();
    $like_count = $like_result['total'] ?? 0;

    // Check if current user liked this comment
    $user_like_stmt = $conn->prepare("SELECT 1 FROM comment_likes WHERE comment_id = ? AND user_id = ?");
    $user_like_stmt->bind_param("ii", $comment['id'], $_SESSION['user_id']);
    $user_like_stmt->execute();
    $user_liked = $user_like_stmt->get_result()->num_rows > 0;

    $like_icon = $user_liked ? "❤️" : "🤍";

    echo "<div class='like-box'>";
    echo "<a href='#' onclick='toggleLike({$comment['id']}, \"comment\"); return false;'>";
    echo "$like_icon $like_count";
    echo "</a>";
    echo "</div>";

    // ✏️ Edit / 🗑️ Delete / ↩️ Reply buttons
    echo "<div class='comment-actions'>";
    
    // Reply button (for all users)
    echo "<a href='#' onclick='replyToComment({$comment['id']}); return false;'>↩️ Reply</a>";
    
    // Edit/Delete buttons (only for comment owner)
    if ($comment['user_id'] == $_SESSION['user_id']) {
        $escaped_comment = addslashes(htmlspecialchars($comment['comment']));
        echo "<a href='#' onclick='editComment({$comment['id']}, `{$escaped_comment}`); return false;'>✏️ Edit</a>";
        echo "<a href='#' onclick='deleteComment({$comment['id']}); return false;' style='color:red;'>🗑️ Delete</a>";
    }
    
    echo "</div>";

    echo "</div>"; // Close comment-item
}

// Organize comments into parent-child structure
$comments_by_parent = [];
while ($row = $result->fetch_assoc()) {
    $parent_id = $row['parent_id'] ?: 0;
    if (!isset($comments_by_parent[$parent_id])) {
        $comments_by_parent[$parent_id] = [];
    }
    $comments_by_parent[$parent_id][] = $row;
}

// Recursive function to display comments with proper nesting
function displayNestedComments($parent_id, $level, $comments_by_parent, $conn) {
    if (!isset($comments_by_parent[$parent_id])) {
        return;
    }
    
    foreach ($comments_by_parent[$parent_id] as $comment) {
        displayComment($comment, $level, $conn);
        // Display replies recursively
        displayNestedComments($comment['id'], $level + 1, $comments_by_parent, $conn);
    }
}

// Display comments
if (!empty($comments_by_parent)) {
    // Start with top-level comments (parent_id = 0 or NULL)
    displayNestedComments(0, 0, $comments_by_parent, $conn);
} else {
    echo "<p>No comments yet. Be the first to comment!</p>";
}
?>