<?php
session_start();
require_once "../includes/config.php";

// 🛡️ Must be logged in
if (!isset($_SESSION["user_id"])) {
    echo "error:not_logged_in";
    exit();
}

// 🧩 Validate inputs
if (empty($_POST["comment_id"]) || empty($_POST["comment"])) {
    echo "error:missing_fields";
    exit();
}

$comment_id = intval($_POST["comment_id"]);
$blog_id = isset($_POST["blog_id"]) ? intval($_POST["blog_id"]) : 0;
$user_id = $_SESSION["user_id"];
$new_comment = trim($_POST["comment"]);

// 🔍 Verify ownership
$stmt = $conn->prepare("SELECT * FROM comments WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $comment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "error:no_permission";
    exit();
}

// ✏️ Update comment
$update = $conn->prepare("UPDATE comments SET comment = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
$update->bind_param("sii", $new_comment, $comment_id, $user_id);

if ($update->execute()) {
    echo "success";
} else {
    echo "error:update_failed";
}
?>
