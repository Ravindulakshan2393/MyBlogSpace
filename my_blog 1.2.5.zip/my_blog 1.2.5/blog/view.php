<?php
session_start();
require_once "../includes/config.php";

// Redirect if not logged in
if (!isset($_SESSION["user_id"])) {
  header("Location: ../login.php");
  exit();
}

// Validate blog ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
  echo "❌ No blog post selected.";
  exit();
}

$blog_id = intval($_GET['id']);
$user_id = $_SESSION["user_id"];
$message = "";

// Helper function: Convert timestamp to time ago
function timeAgo($datetime) {
  $timestamp = strtotime($datetime);
  $diff = time() - $timestamp;
  if ($diff < 60) return "just now";
  elseif ($diff < 3600) return floor($diff / 60) . " minutes ago";
  elseif ($diff < 86400) return floor($diff / 3600) . " hours ago";
  elseif ($diff < 172800) return "yesterday";
  else return floor($diff / 86400) . " days ago";
}

// Fetch blog post
$stmt = $conn->prepare("
  SELECT blogpost.*, user.username 
  FROM blogpost 
  JOIN user ON blogpost.user_id = user.id 
  WHERE blogpost.id = ?
");
$stmt->bind_param("i", $blog_id);
$stmt->execute();
$blog = $stmt->get_result()->fetch_assoc();
if (!$blog) {
  echo "❌ Blog not found.";
  exit();
}

include "../includes/header.php";
?>

<div style="max-width:800px; margin:0 auto; padding:0 20px;">
  <a href="../index.php" class="button">← Back to Home</a>

  <div class="blog">
    <h2><?php echo htmlspecialchars($blog['title']); ?></h2>
    <p class="meta">
  By <?php echo htmlspecialchars($blog['username']); ?> | <?php echo $blog['created_at']; ?>

  <?php
  // Get post like count
  $like_q = $conn->prepare("SELECT COUNT(*) AS total FROM post_likes WHERE blog_id = ?");
  $like_q->bind_param("i", $blog_id);
  $like_q->execute();
  $like_r = $like_q->get_result()->fetch_assoc();
  $like_count = $like_r['total'];

  // Check if user liked post
  $user_liked_q = $conn->prepare("SELECT 1 FROM post_likes WHERE blog_id = ? AND user_id = ?");
  $user_liked_q->bind_param("ii", $blog_id, $user_id);
  $user_liked_q->execute();
  $user_liked = $user_liked_q->get_result()->num_rows > 0;

  $icon = $user_liked ? "❤️" : "🤍";
  ?>

  <a href="#" onclick="toggleLike(<?php echo $blog_id; ?>, 'post'); return false;">
    <?php echo $icon . " " . $like_count; ?>
  </a>
</p>

    <?php if (!empty($blog['image'])): ?>
      <img src="../uploads/<?php echo htmlspecialchars($blog['image']); ?>" 
           alt="Blog Image" 
           style="max-width:100%; border-radius:10px; margin:10px 0;">
    <?php endif; ?>

    <p><?php echo nl2br(htmlspecialchars($blog['content'])); ?></p>
  </div>

  <!-- 💬 Comment Section -->
  <div class="form-box">
    <h3>💬 Comments</h3>
    <form id="commentForm">
      <textarea name="comment" id="commentText" rows="3" placeholder="Write your comment..." required></textarea><br>
      <button type="submit">Post Comment</button>
    </form>
    <p id="commentMessage"></p>
    <hr>

    <!-- Where comments will load -->
    <div id="commentsList">
      <p>Loading comments...</p>
    </div>
  </div>
</div>

<?php include "../includes/footer.php"; ?>

<script>
const blogId = <?php echo $blog_id; ?>;
const commentsList = document.getElementById("commentsList");
const form = document.getElementById("commentForm");
const text = document.getElementById("commentText");
const msg = document.getElementById("commentMessage");

let refreshTimer = null;

// Load comments
async function fetchComments() {
  try {
    const res = await fetch(`fetch_comments.php?blog_id=${blogId}&t=${new Date().getTime()}`);
    const html = await res.text();
    commentsList.innerHTML = html;
  } catch (error) {
    console.error('Error fetching comments:', error);
    commentsList.innerHTML = '<p>Error loading comments</p>';
  }
}

// Handle new comment
form.addEventListener("submit", async e => {
  e.preventDefault();
  const comment = text.value.trim();
  if (!comment) return;

  try {
    const bodyData = `blog_id=${blogId}&comment=${encodeURIComponent(comment)}${replyTo ? `&parent_id=${replyTo}` : ''}`;

    const res = await fetch("add_comment.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: bodyData
    });

    const result = await res.text();
    if (result.includes("success")) {
      msg.textContent = "✅ Comment added!";
      msg.className = "message success";
      text.value = "";
      replyTo = null;
      cancelReply();
      
      // Clear any existing refresh timer and fetch comments once
      if (refreshTimer) clearTimeout(refreshTimer);
      setTimeout(fetchComments, 100); // Small delay to ensure DB is updated
    } else {
      msg.textContent = "❌ Failed to add comment.";
      msg.className = "message error";
    }
  } catch (error) {
    msg.textContent = "❌ Network error. Please try again.";
    msg.className = "message error";
  }
});

// Edit comment function
function editComment(id, oldComment) {
  const commentDiv = document.getElementById(`comment-${id}`);
  if (!commentDiv) {
    console.error('Comment div not found:', `comment-${id}`);
    return;
  }

  // Create textarea
  const textarea = document.createElement("textarea");
  textarea.value = oldComment;
  textarea.style.width = "100%";
  textarea.rows = "3";
  textarea.className = "edit-textarea";
  textarea.style.marginBottom = "10px";

  // Create save/cancel buttons
  const saveBtn = document.createElement("button");
  saveBtn.textContent = "💾 Save";
  saveBtn.className = "edit-btn";

  const cancelBtn = document.createElement("button");
  cancelBtn.textContent = "❌ Cancel";
  cancelBtn.className = "cancel-btn";

  // Save old HTML (in case of cancel)
  const originalHTML = commentDiv.innerHTML;

  // Replace content with editor
  commentDiv.innerHTML = "";
  commentDiv.appendChild(textarea);
  commentDiv.appendChild(saveBtn);
  commentDiv.appendChild(cancelBtn);

  // Save action
  saveBtn.onclick = async () => {
    const newComment = textarea.value.trim();
    if (!newComment) return alert("Please write something!");
    
    try {
      const res = await fetch("edit_comment.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `comment_id=${id}&comment=${encodeURIComponent(newComment)}&blog_id=${blogId}`
      });
      
      const result = await res.text();
      if (result.includes("success")) {
        fetchComments();
      } else {
        alert("❌ Failed to update comment.");
      }
    } catch (error) {
      alert("❌ Network error. Please try again.");
    }
  };

  // Cancel action
  cancelBtn.onclick = () => {
    commentDiv.innerHTML = originalHTML;
  };
}

// Delete comment function - FIXED
async function deleteComment(id) {
  if (confirm("Are you sure you want to delete this comment?")) {
    try {
      const res = await fetch(`delete_comment.php?id=${id}`);
      const result = await res.text();
      
      if (res.ok) {
        fetchComments();
      } else {
        alert("❌ Failed to delete comment: " + result);
      }
    } catch (error) {
      alert("❌ Network error. Please try again.");
    }
  }
}

// Reply system
let replyTo = null;

function replyToComment(parentId) {
  replyTo = parentId;
  const box = document.getElementById("commentMessage");
  box.innerHTML = `↩️ Replying to comment <a href='#' onclick='cancelReply(); return false;'>❌ Cancel</a>`;
  box.className = "message";
  document.getElementById("commentText").focus();
  document.getElementById("commentText").placeholder = "Write your reply...";
}

function cancelReply() {
  replyTo = null;
  document.getElementById("commentMessage").innerHTML = "";
  document.getElementById("commentMessage").className = "";
  document.getElementById("commentText").placeholder = "Write your comment...";
}

// Like toggle function
async function toggleLike(id, type) {
  try {
    const res = await fetch("like_toggle.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `id=${id}&type=${type}`
    });
    
    const result = await res.text();
    console.log('Like result:', result);

    // Refresh comments or post based on type
    if (type === "comment") {
      fetchComments();
    } else if (type === "post") {
      // Simple page reload for post likes (more reliable)
      location.reload();
    }
  } catch (error) {
    console.error('Like error:', error);
  }
}

// Initial load
fetchComments();

// REMOVED AUTO-REFRESH to prevent duplicates
</script>

</body>
</html>
