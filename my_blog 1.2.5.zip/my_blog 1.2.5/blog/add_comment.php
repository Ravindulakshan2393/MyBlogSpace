<?php
session_start();
require_once "../includes/config.php";

// Make sure user is logged in
if (!isset($_SESSION["user_id"])) {
    echo "error:not_logged_in";
    exit();
}

// Check that blog id and comment are provided
if (empty($_POST["blog_id"]) || empty($_POST["comment"])) {
    echo "error:missing_fields";
    exit();
}

$blog_id = intval($_POST["blog_id"]);
$user_id = $_SESSION["user_id"];
$comment = trim($_POST["comment"]);
$parent_id = isset($_POST["parent_id"]) && $_POST["parent_id"] !== "" 
            ? intval($_POST["parent_id"]) 
            : NULL; 

// Verify that the blog actually exists
$check = $conn->prepare("SELECT id FROM blogpost WHERE id = ?");
$check->bind_param("i", $blog_id);
$check->execute();
$result = $check->get_result();
if ($result->num_rows === 0) {
    echo "error:no_blog";
    exit();
}

// Insert the comment safely
$stmt = $conn->prepare("INSERT INTO comments (blog_id, user_id, comment, parent_id) VALUES (?, ?, ?,?)");
$stmt->bind_param("iisi", $blog_id, $user_id, $comment, $parent_id);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error:insert_failed";
}
?>
