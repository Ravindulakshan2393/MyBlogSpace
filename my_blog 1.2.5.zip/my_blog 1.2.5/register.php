<?php
// register.php
require_once "includes/config.php"; // config.php already starts session

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"] ?? '');
    $email = trim($_POST["email"] ?? '');
    $password = trim($_POST["password"] ?? '');
    $confirm_password = trim($_POST["confirm_password"] ?? '');

    // === Basic Validation ===
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = "⚠️ Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "⚠️ Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $message = "⚠️ Passwords do not match.";
    } else {
        // === Check if email already exists ===
        $check = $conn->prepare("SELECT id FROM user WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "⚠️ Email already registered.";
        } else {
            // === Create new account ===
            $token = bin2hex(random_bytes(16));
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("INSERT INTO user (username, email, password, verify_token, is_verified) VALUES (?, ?, ?, ?, 0)");
            $stmt->bind_param("ssss", $username, $email, $hashed_password, $token);

            if ($stmt->execute()) {
                // === Prepare verification link ===
                $base = rtrim($_ENV['APP_URL'] ?? 'http://localhost/my_blog', '/');
                $verify_link = $base . "/verify.php?token=" . urlencode($token);

                // === Try to send mail using PHPMailer (Composer or manual) ===
                $sent = false;
                $errorInfo = "";

                // attempt to autoload composer PHPMailer or manual files
                try {
                    if (file_exists(__DIR__ . '/vendor/phpmailer/src/PHPMailer.php')) {
                        require_once __DIR__ . '/vendor/phpmailer/src/PHPMailer.php';
                        require_once __DIR__ . '/vendor/phpmailer/src/SMTP.php';
                        require_once __DIR__ . '/vendor/phpmailer/src/Exception.php';
                    } elseif (file_exists(__DIR__ . '/phpmailer/src/PHPMailer.php')) {
                        require_once __DIR__ . '/phpmailer/src/PHPMailer.php';
                        require_once __DIR__ . '/phpmailer/src/SMTP.php';
                        require_once __DIR__ . '/phpmailer/src/Exception.php';
                    } else {
                        throw new Exception("PHPMailer not found (install via Composer or place PHPMailer in phpmailer/).");
                    }

                    // instantiate by fully-qualified name (no 'use' required)
                    $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = $_ENV['MAIL_HOST'] ?? 'smtp.example.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = $_ENV['MAIL_USER'] ?? '';
                    $mail->Password = $_ENV['MAIL_PASS'] ?? '';
                    // choose TLS if port 587, else try ssl if 465
                    $port = $_ENV['MAIL_PORT'] ?? 587;
                    $mail->SMTPSecure = (intval($port) === 465) ? 'ssl' : 'tls';
                    $mail->Port = $port;
                    $mail->setFrom($_ENV['MAIL_FROM'] ?? ($_ENV['MAIL_USER'] ?? 'no-reply@example.com'), $_ENV['MAIL_FROM_NAME'] ?? 'MyBlogSpace');
                    $mail->addAddress($email);
                    $mail->isHTML(true);
                    $mail->Subject = "Verify your MyBlogSpace account";
                    $mail->Body = "Hi <b>" . htmlspecialchars($username) . "</b>,<br><br>Please verify your email by clicking below:<br>
                                   <a href='" . htmlspecialchars($verify_link) . "'>" . htmlspecialchars($verify_link) . "</a><br><br>Thank you!";

                    $mail->send();
                    $sent = true;
                } catch (\PHPMailer\PHPMailer\Exception $e) {
                    $errorInfo = $e->getMessage();
                } catch (Exception $e) {
                    $errorInfo = $e->getMessage();
                }

                if ($sent) {
                    $message = "✅ Registration successful! Please check your email to verify your account.";
                } else {
                    // fallback: show link on screen (useful for local development)
                    $message = "✅ Registration successful!<br>
                                ⚠️ Email sending not configured or failed ({$errorInfo}). Use this link to verify:<br>
                                <a href='" . htmlspecialchars($verify_link) . "'>" . htmlspecialchars($verify_link) . "</a>";
                }
            } else {
                $message = "❌ Something went wrong. Please try again.";
            }
        }
    }
}

include "includes/header.php";
?>

<h2>📝 Register Account</h2>

<?php if (!empty($message)) echo "<div class='message'>".$message."</div>"; ?>

<form method="POST" action="">
  <label>Username:</label><br>
  <input type="text" name="username" required><br><br>

  <label>Email:</label><br>
  <input type="email" name="email" required><br><br>

  <label>Password:</label><br>
  <input type="password" name="password" required><br><br>

  <label>Confirm Password:</label><br>
  <input type="password" name="confirm_password" required><br><br>

  <button type="submit">Register</button>
</form>

<p>Already have an account? <a href="login.php">Login here</a></p>

<?php include "includes/footer.php"; ?>
