<?php
// ===============================
// 🔐 LOGIN PAGE (with email verification)
// ===============================
require_once "includes/config.php";

$message = "";

// 🧾 When form is submitted:
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if (empty($email) || empty($password)) {
        $message = "⚠️ Please fill in all fields.";
    } else {
        // 🔍 Find user by email
        $stmt = $conn->prepare("SELECT * FROM user WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            if (password_verify($password, $row["password"])) {
                // 🚨 Optional: Email verification
                if (isset($row["is_verified"]) && $row["is_verified"] == 0) {
                    $message = "⚠️ Please verify your email before logging in.";
                } else {
                    // ✅ Success: Set session data
                    $_SESSION["user_id"] = $row["id"];
                    $_SESSION["username"] = $row["username"];
                    $_SESSION["email"] = $row["email"];
                    $_SESSION["role"] = $row["role"] ?? "user";

                    // ✅ (Optional) Remember Me cookie feature
                    if (!empty($_POST["remember_me"])) {
                        $token = bin2hex(random_bytes(32));
                        setcookie("remember_token", $token, time() + (86400 * 7), "/", "", false, true);
                        $update = $conn->prepare("UPDATE user SET remember_token=? WHERE id=?");
                        $update->bind_param("si", $token, $row["id"]);
                        $update->execute();
                    }

                    header("Location: index.php");
                    exit();
                }
            } else {
                $message = "❌ Incorrect password.";
            }
        } else {
            $message = "❌ No account found with that email.";
        }
    }
}

include "includes/header.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - MyBlogSpace</title>
  <link rel="stylesheet" href="assets/css/style.css">

  <script>
  function toggleTheme() {
    document.body.classList.toggle('dark');
    localStorage.setItem('theme', document.body.classList.contains('dark') ? 'dark' : 'light');
  }

  window.onload = () => {
    if (localStorage.getItem('theme') === 'dark') {
      document.body.classList.add('dark');
    }
  };
  </script>
</head>
<body>
  <h2>🔐 Login</h2>
  <?php if (!empty($message)) echo "<p>$message</p>"; ?>

  <form method="POST" action="">
    <label>Email:</label><br>
    <input type="email" name="email" placeholder="Enter your email" required><br><br>

    <label>Password:</label><br>
    <input type="password" name="password" placeholder="Enter your password" required><br><br>

    <label><input type="checkbox" name="remember_me"> Remember me</label><br><br>

    <button type="submit">Login</button>
    <p><a href="forgot_password.php">🔑 Forgot your password?</a></p>
  </form>

  <p>Don't have an account? <a href="register.php">Register here</a></p>

  <?php include "includes/footer.php"; ?>
</body>
</html>
